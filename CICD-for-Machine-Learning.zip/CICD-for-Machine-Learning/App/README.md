---
title: Drug Classification
emoji: 📉
colorFrom: yellow
colorTo: blue
sdk: gradio
sdk_version: 5.33.0
app_file: app.py
pinned: false
---
